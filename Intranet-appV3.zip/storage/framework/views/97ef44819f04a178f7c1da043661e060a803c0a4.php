
<?php $__env->startSection('title', 'Create New Group'); ?>
<?php $__env->startSection('body-class', 'bg-light'); ?>

<?php $__env->startSection('admin-content'); ?>
<div class="group-create-wrap">
    
    <div class="container" id="create-group-form-wrap">
        <div class="row page-header my-4 pt-4">
            <div class="col">
                <h3 class="page-title"><?php echo e(__('Create group')); ?></h3>
                <hr>
            </div>
        </div>

        <div class="row">
            <div class="col">

                <div class="text-left mb-5">
                    <img src="<?php echo e(asset('images/logo.png')); ?>">
                </div>

                <form action="<?php echo e(route('group.store', app()->getLocale())); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="group_name"><?php echo e(__('Name')); ?></label>
                            <input type="text" class="form-control" id="group_name" name="name" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6 d-flex flex-wrap">
                            <label for="" class="d-block w-100"><?php echo e(__('Select a group color:')); ?></label>

                            <div class="custom-control custom-radio mr-4 my-1 body-green">
                                <input type="radio" id="group_color_green" name="group_color" value="green" class="custom-control-input" checked>
                                <label class="custom-control-label" for="group_color_green">Green</label>
                                <span class="bg-color rounded-circle show-group-color"></span>
                            </div>
                            <div class="custom-control custom-radio mr-4 my-1 body-blue">
                                <input type="radio" id="group_color_blue" name="group_color" value="blue" class="custom-control-input">
                                <label class="custom-control-label" for="group_color_blue">Blue</label>
                                <span class="bg-color rounded-circle show-group-color"></span>
                            </div>
                            <div class="custom-control custom-radio mr-4 my-1 body-yellow">
                                <input type="radio" id="group_color_yellow" name="group_color" value="yellow" class="custom-control-input">
                                <label class="custom-control-label" for="group_color_yellow">Yellow</label>
                                <span class="bg-color rounded-circle show-group-color"></span>
                            </div>
                            <div class="custom-control custom-radio mr-4 my-1 body-red">
                                <input type="radio" id="group_color_red" name="group_color" value="red" class="custom-control-input">
                                <label class="custom-control-label" for="group_color_red">Red</label>
                                <span class="bg-color rounded-circle show-group-color"></span>
                            </div>
                            <div class="custom-control custom-radio mr-4 my-1 body-pink">
                                <input type="radio" id="group_color_pink" name="group_color" value="pink" class="custom-control-input">
                                <label class="custom-control-label" for="group_color_pink">Pink</label>
                                <span class="bg-color rounded-circle show-group-color"></span>
                            </div>
                            <div class="custom-control custom-radio mr-4 my-1 body-orange">
                                <input type="radio" id="group_color_orange" name="group_color" value="orange" class="custom-control-input">
                                <label class="custom-control-label" for="group_color_orange">Orange</label>
                                <span class="bg-color rounded-circle show-group-color"></span>
                            </div>
                            <div class="custom-control custom-radio mr-4 my-1 body-teal">
                                <input type="radio" id="group_color_teal" name="group_color" value="teal" class="custom-control-input">
                                <label class="custom-control-label" for="group_color_teal">Teal</label>
                                <span class="bg-color rounded-circle show-group-color"></span>
                            </div>
                            <div class="custom-control custom-radio mr-4 my-1 body-violet">
                                <input type="radio" id="group_color_violet" name="group_color" value="violet" class="custom-control-input">
                                <label class="custom-control-label" for="group_color_violet">Violet</label>
                                <span class="bg-color rounded-circle show-group-color"></span>
                            </div>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="group_archive_start_date"><?php echo e(__('User access date')); ?></label>
                            <input type="date" class="form-control" id="group_archive_start_date" name="archive_start_date" required>
                            <small class="form-text text-muted"><?php echo e(__('This is the date users will get the first access to the boards')); ?></small>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="group_start_date"><?php echo e(__('Events Start date')); ?></label>
                            <input type="date" class="form-control" id="group_start_date" name="start_date" required>
                            <small class="form-text text-muted"><?php echo e(__('This is the date the event starts')); ?></small>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="group_end_date"><?php echo e(__('Events End date')); ?></label>
                            <input type="date" class="form-control" id="group_end_date" name="end_date" required>
                        </div>
                    </div>



                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="archive_group_end_date"><?php echo e(__('Archive date')); ?></label>
                            <input type="date" class="form-control" id="archive_group_end_date" name="archive_end_date" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <label for="" class="d-block w-100"><?php echo e(__('Select group admins:')); ?></label>

                        <div class="form-group col-md-6">
                            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" value="<?php echo e($admin->id); ?>" name="group_admins[]" id="group_admin_<?php echo e($admin->id); ?>">
                                <label class="custom-control-label" for="group_admin_<?php echo e($admin->id); ?>"><?php echo e($admin->name); ?></label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary"><?php echo e(__('Add New Group')); ?></button>
                </form>
            </div>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Intranet-app\resources\views/backend/groups/create.blade.php ENDPATH**/ ?>