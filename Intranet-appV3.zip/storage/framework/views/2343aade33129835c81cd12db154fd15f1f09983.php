
<?php $__env->startSection('title', 'Create New User'); ?>
<?php $__env->startSection('body-class', 'bg-light'); ?>

<?php $__env->startSection('admin-content'); ?>
<div class="users-create-wrap">
    
    <div class="container" id="create-group-form-wrap">
        <div class="row page-header my-4 pt-4">
            <div class="col">
                <h3 class="page-title"><?php echo e(__('Create & Invite user')); ?></h3>
                <hr>
            </div>
        </div>

        <div class="row">
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <div class="col">
                <form action="<?php echo e(route('save-user',app()->getLocale())); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="group_name"><?php echo e(__('Name')); ?></label>
                            <input type="text" class="form-control" id="group_name" name="name" placeholder="ex: Adam Levi" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="user_profile_image"><?php echo e(__('Profile Image')); ?></label>
                            <input type="file" class="form-control-file" id="user_profile_image" name="avatar">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="user_email"><?php echo e(__('Email')); ?></label>
                            <input type="email" class="form-control" id="user_email" name="email" placeholder="email@domain.com" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="user_phone_no"><?php echo e(__('Phone')); ?></label>
                            <input type="tel" class="form-control" id="user_phone_no" name="phone" placeholder="+470156421" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="exampleFormControlTextarea1"><?php echo e(__('About / Bio')); ?></label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="bio"></textarea>
                        </div>
                    </div>
                    <input type="hidden" name="role" value="user">

                    <div class="form-row">
                        <div class="form-group col-md-6 d-flex flex-wrap">
                            <label for="" class="d-block w-100"><?php echo e(__('Assign a group:')); ?></label>

                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="custom-control custom-radio select-group-btn mr-4 my-1">
                                    <input type="radio" id="group_<?php echo e($group->id); ?>" name="group_id" class="custom-control-input" value="<?php echo e($group->id); ?>">
                                    <label class="custom-control-label" for="group_<?php echo e($group->id); ?>"><?php echo e($group->name); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6 d-flex flex-wrap">
                            <label for="" class="d-block w-100"><?php echo e(__('Select primary contact:')); ?></label>

                            <div class="form-group col-md-6" id="primary-contacts-wrap">
                                
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary"><?php echo e(__('Invite & Add New User')); ?></button>
                </form>
            </div>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Intranet-app\resources\views/backend/users/create.blade.php ENDPATH**/ ?>