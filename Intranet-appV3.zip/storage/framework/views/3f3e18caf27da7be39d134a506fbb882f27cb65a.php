
<?php $__env->startSection('body-class', 'bg-light'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="users-create-wrap">
        
        <div class="container" id="create-group-form-wrap">
            <div class="row page-header my-4 pt-4">
                <div class="col">
                    <h3 class="page-title"><?php echo e(__('Edit Board')); ?></h3>
                    <hr>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <form action="<?php echo e(route('update-board', [ app()->getLocale(), $board->id ] )); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="group_name"><?php echo e(__('Name')); ?></label>
                                <input type="text" class="form-control" id="group_name" name="name" value="<?php echo e($board->name); ?>" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save Changes')); ?></button>
                    </form>
                </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Intranet-app\resources\views/backend/boards/edit.blade.php ENDPATH**/ ?>