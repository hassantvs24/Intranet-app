
<?php $__env->startSection('title', 'User Settings'); ?>
<?php $__env->startSection('body-class', 'user-dashboard bg-light body-teal'); ?>

<?php $__env->startSection('content'); ?>
    <div class="users-create-wrap">
        
        <div class="container" id="create-group-form-wrap">
            <div class="row page-header my-4 pt-4">
                <div class="col">
                    <h3 class="page-title"><?php echo e(__('Account Settings')); ?></h3>
                    <hr>
                </div>
            </div>

            <div class="row mb-4">
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>
            </div>

            <div class="row">
                <div class="col">
                    <form action="<?php echo e(route('user-account-settings', app()->getLocale())); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="group_name"><?php echo e(__('Name')); ?></label>
                                <input type="text" class="form-control" id="group_name" name="group_name" placeholder="ex: Adam Levi" required value="<?php echo e($user->name); ?>">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="user_profile_image"> <?php echo e(__('Profile Image')); ?></label>
                                <input type="file" class="form-control-file" id="user_profile_image" name="user_profile_image">
                            </div>
                        </div>


                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="user_email"><?php echo e(__('User Email')); ?></label>
                                <input type="email" class="form-control" id="user_email" name="user_email" placeholder="email@domain.com" required value="<?php echo e($user->email); ?>">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="user_phone_no"><?php echo e(__('User Phone')); ?></label>
                                <input type="tel" class="form-control" id="user_phone_no" name="user_phone_no" placeholder="+470156421" required value="<?php echo e($user->phone); ?>">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="user_language"> <?php echo e(__( 'Language' )); ?> </label>
                                <select name="user_language">
                                    <option value=""></option>
                                    <option value="en" <?php if( $user->language == 'en' ): ?> <?php echo e('selected'); ?> <?php endif; ?> > <?php echo e(__( 'English' )); ?></option>
                                    <option value="nor" <?php if( $user->language == 'nor' ): ?> <?php echo e('selected'); ?> <?php endif; ?> >  <?php echo e(__( 'Norwegian' )); ?></option>
                                </select>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="exampleFormControlTextarea1"><?php echo e(__('About / Bio')); ?></label>
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"> <?php echo e($user->bio); ?> </textarea>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save Changes')); ?></button>
                    </form>
                </div>

                <div class="col">
                    <h4 class="mb-4"> <?php echo e(__('Group Info')); ?> </h4>
                    <div>
                        <span class="font-weight-bold"><?php echo e(__('Primary contact')); ?></span> :
                        <span>Group admin</span>
                    </div>
                    <div>
                        <span class="font-weight-bold"><?php echo e(__('Group Color')); ?></span> :
                        <span>Red</span>
                    </div>
                    <div>
                        <span class="font-weight-bold"><?php echo e(__('Start date')); ?></span> :
                        <span>10/08/2020</span>
                    </div>
                    <div>
                        <span class="font-weight-bold"><?php echo e(__('End date')); ?></span> :
                        <span>25/08/2020</span>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Intranet-app\resources\views/backend/users/account-settings.blade.php ENDPATH**/ ?>