

<?php $__env->startSection('body-class', 'user-dashboard body-teal'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                
            </div>
        </div>
        <!-- START data cards -->
        <div class="data-cards">
            <div class="row">
                <?php if( !@empty ( auth()->user()->group->boards ) ): ?>
                    <input type="hidden" name="board_id" id="board_id" value="<?php echo e(auth()->user()->group->boards->id); ?>" />
                <?php endif; ?>

                <?php if( count( $cards ) > 0 ): ?>
                    <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if( $card->card_type == 'normal'): ?>
                            <div class="col col-md-4 my-4">
                        <?php elseif( $card->card_type == 'calender'): ?>
                            <div class="col col-md-12 my-12">
                        <?php endif; ?>
                                <div class="card">
                                    <div class="card-header bg-color">
                                        <h3 class="cart-title mb-0 txt-color"> <?php echo e($card->title); ?> </h3>
                                    </div>
                                    <div class="card-body">
                                        <?php if( $card->card_type == 'normal'): ?>
                                            <?php echo $card->html_content; ?>

                                        <?php elseif( $card->card_type == 'calender'): ?>
                                            <div id="calendar"></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <!-- START card -->

                <!-- END card -->
                <!-- START card -->

                <!-- END card -->
                <!-- START card -->

                <!-- END card -->
                <!-- START card -->

                <!-- END card -->
                <!-- START card -->

                <!-- END card -->
            </div>
        </div>
        <!-- END data cards -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Intranet-app\resources\views/home.blade.php ENDPATH**/ ?>