
<?php $__env->startSection('body-class', 'bg-light'); ?>

<?php $__env->startSection('admin-content'); ?>
<div class="users-create-wrap">
    
    <div class="container" id="create-group-form-wrap">
        <div class="row page-header my-4 pt-4">
            <div class="col">
                <h3 class="page-title"><?php echo e(__('Create Board')); ?></h3>
                <hr>
            </div>
        </div>

        <div class="row">
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <div class="col">
                <form action="<?php echo e(route('store-board', app()->getLocale() )); ?>"  method="post">
                    <?php echo csrf_field(); ?>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="group_name"><?php echo e(__('Name')); ?></label>
                            <input type="text" class="form-control" id="group_name" name="name" placeholder="ex: Adam Levi" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6 d-flex flex-wrap">
                            <label for="" class="d-block w-100"><?php echo e(__('Select a group:')); ?></label>

                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="custom-control custom-radio select-group-btn mr-4 my-1">
                                <input type="radio" id="group_<?php echo e($group->id); ?>" name="user_group" class="custom-control-input" value="<?php echo e($group->id); ?>">
                                <label class="custom-control-label" for="group_<?php echo e($group->id); ?>"><?php echo e($group->name); ?></label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>

                    
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="group_start_date"><?php echo e(__('Start date')); ?></label>
                            <input type="date" class="form-control" id="group_start_date" name="group_start_date" value="" disabled>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="group_end_date"><?php echo e(__('End date')); ?></label>
                            <input type="date" class="form-control" id="group_end_date" name="group_end_date" value="" disabled>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary"><?php echo e(__('Create Board')); ?></button>

                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="alert alert-primary mt-4 font-weight-bold" role="alert">
                                <?php echo e(__('To add information cards for the users of this group & board, please save the board first.')); ?>

                                <?php echo e(__('After saving you will get the option to add or edit information cards. Thank you.')); ?>

                            </div>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
    
</div>

<script>
    $(".select-group-btn input[name='user_group']").change(function () {
        // get selected group id
        let group_id = $(this).val()

        // group data
        axios.get('/api/groups/'+group_id)
        .then(function (response) {
            // console.log(response.data.data)
            let data = response.data.data
            let start_date = data.start_date
            let end_date = data.end_date
            // set srat && end date
            $('#group_start_date').val(start_date)
            $('#group_end_date').val(end_date)
        })
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Intranet-app\resources\views/backend/boards/create.blade.php ENDPATH**/ ?>