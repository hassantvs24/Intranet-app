<ul class="nav nav-tabs">
    <li class="nav-item">
        <a class="nav-link <?php echo e(Route::currentRouteName() == 'groups.create' ? 'active':''); ?>" href="<?php echo e(route('groups.create', app()->getLocale())); ?>"><?php echo e(__('Create group')); ?></a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(Route::currentRouteName() == 'groups.board' ? 'active':''); ?>" href="<?php echo e(route('groups.board', app()->getLocale())); ?>"><?php echo e(__('Add Board')); ?></a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(Route::currentRouteName() == 'groups.admin' ? 'active':''); ?>" href="<?php echo e(route('groups.admin', app()->getLocale())); ?>"><?php echo e(__('Add admin')); ?></a>
    </li>

    <li class="nav-item">
        <a class="nav-link <?php echo e(Route::currentRouteName() == 'groups.admin-assign' ? 'active':''); ?>" href="<?php echo e(route('groups.admin-assign', app()->getLocale())); ?>"><?php echo e(__('Group Assign')); ?></a>
    </li>

    <li class="nav-item">
        <a class="nav-link <?php echo e(Route::currentRouteName() == 'groups.invite' ? 'active':''); ?>" href="<?php echo e(route('groups.invite', app()->getLocale())); ?>"><?php echo e(__('Invite users')); ?></a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(Route::currentRouteName() == 'groups.invite-exist' ? 'active':''); ?>" href="<?php echo e(route('groups.invite-exist', app()->getLocale())); ?>"><?php echo e(__('Invite exist users')); ?></a>
    </li>
</ul>
<?php /**PATH C:\wamp64\www\Intranet-app\resources\views/backend/creation/menu.blade.php ENDPATH**/ ?>