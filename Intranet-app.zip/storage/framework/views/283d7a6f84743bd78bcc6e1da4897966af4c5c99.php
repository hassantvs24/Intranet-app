
<?php $__env->startSection('title', 'Group creation'); ?>
<?php $__env->startSection('body-class', 'bg-light'); ?>

<?php $__env->startSection('admin-content'); ?>
<div class="group-create-wrap">
    <div class="container-fluid p-4">
        <div class="row">
            <div class="col mb-4">
                <?php echo $__env->make('backend.creation.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <div class="row">
            <div class="col">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if(session()->has('status')): ?>
                    <div class="alert <?php echo e(session()->get('alert')); ?> alert-dismissible fade show" role="alert">
                        <?php echo e(session()->get('status')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-10">
                <div class="card">
                    <form id="form_cr" action="<?php echo e(route('groups.create.save', app()->getLocale())); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <h5 class="card-header mb-3"><?php echo e(__('Create group')); ?></h5>
                        <div class="card-body">

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-row">
                                        <div class="form-group w-100">
                                            <label for="group_name"><?php echo e(__('Group name')); ?> <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="group_name" name="name" value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(__('Group name')); ?>" required>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group d-flex flex-wrap">
                                            <label for="" class="d-block w-100"><?php echo e(__('Select a group color:')); ?></label>

                                            <div class="custom-control custom-radio mr-4 my-1 body-green">
                                                <input type="radio" id="group_color_green" name="group_color" value="green" class="custom-control-input" checked>
                                                <label class="custom-control-label" for="group_color_green">Green</label>
                                                <span class="bg-color rounded-circle show-group-color"></span>
                                            </div>
                                            <div class="custom-control custom-radio mr-4 my-1 body-blue">
                                                <input type="radio" id="group_color_blue" name="group_color" value="blue" class="custom-control-input">
                                                <label class="custom-control-label" for="group_color_blue">Blue</label>
                                                <span class="bg-color rounded-circle show-group-color"></span>
                                            </div>
                                            <div class="custom-control custom-radio mr-4 my-1 body-yellow">
                                                <input type="radio" id="group_color_yellow" name="group_color" value="yellow" class="custom-control-input">
                                                <label class="custom-control-label" for="group_color_yellow">Yellow</label>
                                                <span class="bg-color rounded-circle show-group-color"></span>
                                            </div>
                                            <div class="custom-control custom-radio mr-4 my-1 body-red">
                                                <input type="radio" id="group_color_red" name="group_color" value="red" class="custom-control-input">
                                                <label class="custom-control-label" for="group_color_red">Red</label>
                                                <span class="bg-color rounded-circle show-group-color"></span>
                                            </div>
                                            <div class="custom-control custom-radio mr-4 my-1 body-pink">
                                                <input type="radio" id="group_color_pink" name="group_color" value="pink" class="custom-control-input">
                                                <label class="custom-control-label" for="group_color_pink">Pink</label>
                                                <span class="bg-color rounded-circle show-group-color"></span>
                                            </div>
                                            <div class="custom-control custom-radio mr-4 my-1 body-orange">
                                                <input type="radio" id="group_color_orange" name="group_color" value="orange" class="custom-control-input">
                                                <label class="custom-control-label" for="group_color_orange">Orange</label>
                                                <span class="bg-color rounded-circle show-group-color"></span>
                                            </div>
                                            <div class="custom-control custom-radio mr-4 my-1 body-teal">
                                                <input type="radio" id="group_color_teal" name="group_color" value="teal" class="custom-control-input">
                                                <label class="custom-control-label" for="group_color_teal">Teal</label>
                                                <span class="bg-color rounded-circle show-group-color"></span>
                                            </div>
                                            <div class="custom-control custom-radio mr-4 my-1 body-violet">
                                                <input type="radio" id="group_color_violet" name="group_color" value="violet" class="custom-control-input">
                                                <label class="custom-control-label" for="group_color_violet">Violet</label>
                                                <span class="bg-color rounded-circle show-group-color"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group w-100">
                                            <label for="group_archive_start_date"><?php echo e(__('User access date')); ?> <span class="text-danger">*</span></label>
                                            <input type="date" class="form-control" id="group_archive_start_date"  value="<?php echo e(old('archive_start_date')); ?>" name="archive_start_date" required>
                                            <small class="form-text text-muted"><?php echo e(__('This is the date users will get the first access to the boards')); ?></small>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">

                                    <div class="form-row">
                                        <div class="form-group w-100">
                                            <label for="group_start_date"><?php echo e(__('Events Start date')); ?> <span class="text-danger">*</span></label>
                                            <input type="date" class="form-control" id="group_start_date" value="<?php echo e(old('start_date')); ?>" name="start_date" required>
                                            <small class="form-text text-muted"><?php echo e(__('This is the date the event starts')); ?></small>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group w-100">
                                            <label for="group_end_date"><?php echo e(__('Events End date')); ?> <span class="text-danger">*</span></label>
                                            <input type="date" class="form-control" id="group_end_date" value="<?php echo e(old('end_date')); ?>" name="end_date" required>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group w-100">
                                            <label for="archive_group_end_date"><?php echo e(__('Archive date')); ?> <span class="text-danger">*</span></label>
                                            <input type="date" class="form-control" id="archive_group_end_date" value="<?php echo e(old('archive_end_date')); ?>" name="archive_end_date" required>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                        <div class="card-footer text-right">
                            <button type="submit" class="btn btn-primary"><?php echo e(__('Store')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nazmul Hossain\Desktop\intranet\Intranet-app\resources\views/backend/creation/group_create.blade.php ENDPATH**/ ?>