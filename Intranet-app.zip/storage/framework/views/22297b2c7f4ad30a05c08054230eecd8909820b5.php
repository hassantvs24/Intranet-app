
<?php $__env->startSection('title', 'Create Board'); ?>
<?php $__env->startSection('body-class', 'bg-light'); ?>

<?php $__env->startSection('admin-content'); ?>
<div class="group-create-wrap">
    <div class="container-fluid p-4">
        <div class="row">
            <div class="col mb-4">
                <?php echo $__env->make('backend.creation.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <div class="row">
            <div class="col">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if(session()->has('status')): ?>
                    <div class="alert <?php echo e(session()->get('alert')); ?> alert-dismissible fade show" role="alert">
                        <?php echo e(session()->get('status')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-10">
                <div class="card">
                    <form id="form_cr" action="<?php echo e(route('groups.board.save', app()->getLocale())); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <h5 class="card-header mb-3"><?php echo e(__('Add Board')); ?></h5>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">

                                    <div class="form-row">
                                        <div class="form-group w-100">
                                            <label for="group_select"><?php echo e(__('Select group')); ?> <span class="text-danger">*</span></label>
                                            <select id="group_select" name="group_id" class="form-control" required>
                                                <option value=""><?php echo e(__('Select group')); ?></option>
                                                <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group w-100">
                                            <label for="board_name"><?php echo e(__('Add new board name')); ?> <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="board_name" placeholder="<?php echo e(__('Board name')); ?>" value="<?php echo e(old('board_name')); ?>" name="board_name" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6"></div>
                            </div>
                        </div>
                        <div class="card-footer text-right">
                            <button type="submit" class="btn btn-primary"><?php echo e(__('Store')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Intranet-app\resources\views/backend/creation/board_create.blade.php ENDPATH**/ ?>