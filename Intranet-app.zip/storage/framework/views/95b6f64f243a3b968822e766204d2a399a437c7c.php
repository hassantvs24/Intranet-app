
<?php $__env->startSection('title', 'Admin creation'); ?>
<?php $__env->startSection('body-class', 'bg-light'); ?>

<?php $__env->startSection('admin-content'); ?>
<div class="group-create-wrap">
    <div class="container-fluid p-4">
        <div class="row">
            <div class="col mb-4">
                <?php echo $__env->make('backend.creation.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <div class="row">
            <div class="col">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if(session()->has('status')): ?>
                    <div class="alert <?php echo e(session()->get('alert')); ?> alert-dismissible fade show" role="alert">
                        <?php echo e(session()->get('status')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-10">
                <div class="card">
                    <form id="form_cr" action="<?php echo e(route('groups.admin.save', app()->getLocale())); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <h5 class="card-header mb-3"><?php echo e(__('Add admin')); ?></h5>
                        <div class="card-body">

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-row">
                                        <div class="form-group w-100">
                                            <label for="group_select"><?php echo e(__('Select group')); ?></label>
                                            <select id="group_select" name="group_id" class="form-control">
                                                <option value=""><?php echo e(__('Select group')); ?></option>
                                                <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group w-100">
                                            <label for="user_select"><?php echo e(__('Select user')); ?> <span class="text-danger">*</span></label>
                                            <select id="user_select" name="users_id" class="form-control" required>
                                                <option value=""><?php echo e(__('Select user')); ?></option>
                                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($row->id); ?>"
                                                            data-email="<?php echo e($row->email); ?>"
                                                            data-name="<?php echo e($row->name); ?>"
                                                            data-phone="<?php echo e($row->phone); ?>"
                                                            data-bio="<?php echo e($row->bio); ?>"
                                                    ><?php echo e($row->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group w-100">
                                            <label for="admin_name"><?php echo e(__('Admin name')); ?> <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="admin_name" value="<?php echo e(old('admin_name')); ?>" name="admin_name" placeholder="ex: Adam Levi" required>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group w-100">
                                            <label for="admin_profile_image"> <?php echo e(__('Profile Image')); ?> </label>
                                            <input type="file" class="form-control-file" id="admin_profile_image" name="avatar">
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-6">

                                    <div class="form-row">
                                        <div class="form-group w-100">
                                            <label for="admin_email"><?php echo e(__('Email')); ?> <span class="text-danger">*</span></label>
                                            <input type="email" class="form-control" id="admin_email" value="<?php echo e(old('email')); ?>" name="email" placeholder="email@domain.com" required>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group w-100">
                                            <label for="admin_phone_no"><?php echo e(__('Phone')); ?> <span class="text-danger">*</span></label>
                                            <input type="tel" class="form-control" id="admin_phone_no" value="<?php echo e(old('phone')); ?>" name="phone" placeholder="+470156421" required>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group w-100">
                                            <label for="admin_bio"><?php echo e(__('About / Bio')); ?></label>
                                            <textarea class="form-control" name="bio" id="admin_bio" rows="3"><?php echo e(old('bio')); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="card-footer text-right">
                            <button type="submit" class="btn btn-primary"><?php echo e(__('Store')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(function () {

            $('#user_select').change(function () {
                var name = $(this).find(':selected').data('name');
                var email = $(this).find(':selected').data('email');
                var phone = $(this).find(':selected').data('phone');
                var bio = $(this).find(':selected').data('bio');

                $('#admin_name').val(name);
                $('#admin_email').val(email);
                $('#admin_phone_no').val(phone);
                $('#admin_bio').val(bio);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Intranet-app\resources\views/backend/creation/admin_create.blade.php ENDPATH**/ ?>