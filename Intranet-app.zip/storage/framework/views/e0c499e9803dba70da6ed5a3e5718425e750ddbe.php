    <div class="row">
        <ul class="navbar-nav ml-auto">
            <?php $__currentLoopData = config('app.languages' ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">


<?php
    if( in_array( Route::currentRouteName(), [ 'edit-infocards', 'view-group', 'edit-group' ] ) ) {
        $segment = Request::segment(4);
    } else{
        $segment = Request::segment(3);
    }
?>


                    <a class="nav-link"
                       href="<?php echo e(route( Route::currentRouteName(), [ $locale, $segment ] )); ?>"
                        <?php if(app()->getLocale() == $locale): ?> style="font-weight: bold; text-decoration: underline" <?php endif; ?>><?php echo e(strtoupper($locale)); ?></a>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php /**PATH C:\Users\Nazmul Hossain\Desktop\intranet\Intranet-app\resources\views/components/language.blade.php ENDPATH**/ ?>