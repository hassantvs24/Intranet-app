<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Intranetair')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>" type="image/x-icon">
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('style'); ?>
    <?php echo $__env->yieldContent('script'); ?>

</head>
<body class="<?php echo $__env->yieldContent('body-class'); ?>">
    
    <div class="top-color-bar"></div>
    
    <div id="app">

        <nav class="navbar navbar-expand-md navbar-light" id="site-header">
            <div class="container-fluid bg-color">
                <a class="navbar-brand" href="<?php echo e(route('main', app()->getLocale())); ?>">
                    <img src="<?php echo e(asset('images/logo.png')); ?>" height="35" alt="">
                </a>


                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login',app()->getLocale() )); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register', app()->getLocale() )); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>

                            <div class="collapse navbar-collapse">
                                <ul class="navbar-nav ml-auto">
                                    <?php $__currentLoopData = config('app.languages' ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="nav-item">
                                            
                                            
                                            <?php
                                                if( in_array( Route::currentRouteName(), [ 'edit-infocards', 'view-group', 'edit-group' ] ) ) {
                                                    $segment = Request::segment(4);
                                                } else{
                                                    $segment = Request::segment(3);
                                                }
                                            ?>


                                            <a class="nav-link"
                                               href="<?php echo e(route( Route::currentRouteName(), [ $locale, $segment ] )); ?>"
                                               <?php if(app()->getLocale() == $locale): ?> style="font-weight: bold; text-decoration: underline" <?php endif; ?>><?php echo e(strtoupper($locale)); ?></a>
                                            
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle font-weight-bold" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">


                                    <a class="dropdown-item" href="<?php echo e(route('home', app()->getLocale() )); ?>">
                                        <?php echo e(__('Dashboard')); ?>

                                    </a>

                                    <a class="dropdown-item" href="<?php echo e(route('user-account-settings', app()->getLocale())); ?>">
                                        <?php echo e(__('Settings')); ?>

                                    </a>

                                    <div class="dropdown-divider"></div>

                                    <a class="dropdown-item" href="<?php echo e(route('logout', app()->getLocale() )); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout',app()->getLocale() )); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        

        <main class="py-0">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH C:\wamp64\www\Intranet-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>